
(() => {
  'use strict';

  if (window.__CC_LITE_MACRO_HUD_V16_GAME_VISUAL__) return;
  window.__CC_LITE_MACRO_HUD_V16_GAME_VISUAL__ = true;

  const STORAGE_KEY = 'cc_lite_macro_hud_v8';

  const BUTTONS = [
    { id:'A', label:'A', type:'button', button:0, x:.82, y:.66, size:60 },
    { id:'B', label:'B', type:'button', button:1, x:.90, y:.56, size:56 },
    { id:'X', label:'X', type:'button', button:2, x:.74, y:.56, size:56 },
    { id:'Y', label:'Y', type:'button', button:3, x:.82, y:.46, size:56 },

    { id:'LB', label:'LB', type:'button', button:4, x:.16, y:.20, size:58 },
    { id:'RB', label:'RB', type:'button', button:5, x:.84, y:.20, size:58 },
    { id:'LT', label:'LT', type:'button', button:6, x:.08, y:.34, size:58 },
    { id:'RT', label:'RT', type:'button', button:7, x:.92, y:.34, size:58 },

    { id:'VIEW', label:'VIEW', type:'button', button:8, x:.25, y:.39, size:48 },
    { id:'MENU', label:'MENU', type:'button', button:9, x:.34, y:.39, size:48 },
    { id:'L3', label:'L3', type:'button', button:10, x:.13, y:.74, size:46 },
    { id:'R3', label:'R3', type:'button', button:11, x:.87, y:.74, size:46 },

    { id:'UP', label:'↑', type:'button', button:12, x:.26, y:.64, size:50 },
    { id:'DOWN', label:'↓', type:'button', button:13, x:.26, y:.79, size:50 },
    { id:'LEFT', label:'←', type:'button', button:14, x:.19, y:.715, size:50 },
    { id:'RIGHT', label:'→', type:'button', button:15, x:.33, y:.715, size:50 },

    { id:'LS', label:'LS', type:'stick', stick:'L', x:.16, y:.86, size:92 },
    { id:'RS', label:'RS', type:'stick', stick:'R', x:.84, y:.83, size:92 }
  ];

  const COMMANDS = BUTTONS.filter(b => b.type === 'button').map(b => ({ id:b.id, label:b.label, button:b.button }));

  const DEFAULT = {
    enabled: true,
    visible: true,
    edit: false,
    menuOpen: false,
    activeTab: 'hud',
    activeHud: 1,
    onlyInGame: true,
    gameDetected: false,
    opacity: 72,
    huds: {},
    gameHudMap: {},
    gameProfiles: {},
    currentGame: '',
    layout: null,
    macros: [],
    builder: { name:'', sequence:[], editing:null, mode:'combo' },
    selected: null,
    floatingSticks: true,
    analogSensL: 100,
    analogSensR: 100,
    analogDeadzoneL: 0,
    analogDeadzoneR: 0,
    ultraHD: false,
    ultraLevel: 55,
    visualMode: 'realistic',
    bubble: { x: 18, y: 18 }
  };

  let cfg = loadConfig();
  let root, layer, bubble, panel, toastEl;
  let saveTimer = null;
  let lastActionAt = 0;
  let bubbleDrag = null;
  let gamepad = createGamepad();
  const pressedPointers = new Map();
  const dragging = new Map();
  const activeSticks = { L:null, R:null };
  const activeRepeatMacros = new Map();
  const activeMacroPresses = new Map();
  let activeInputFrame = 0;

  // Resposta 0ms: o comando entra no exato momento do toque.
  // Segurança: clique MUITO curto fica vivo por alguns frames para o xCloud não perder.
  const INPUT_RESPONSE_MS = 0;
  const QUICK_TAP_SAFETY_MS = 38;

  function clone(v) { return JSON.parse(JSON.stringify(v)); }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  function loadConfig() {
    try {
      return normalize({ ...DEFAULT, ...(JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}')) });
    } catch {
      return normalize({ ...DEFAULT });
    }
  }

  function saveConfig(immediate = false) {
    saveCurrentGameProfile();
    const write = () => {
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg)); } catch (_) {}
    };
    if (immediate) {
      if (saveTimer) clearTimeout(saveTimer);
      saveTimer = null;
      write();
      return;
    }
    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      saveTimer = null;
      write();
    }, 250);
  }

  function normalize(next) {
    next = { ...DEFAULT, ...(next || {}) };
    if (!next.layout) next.layout = defaultLayout();
    if (!Array.isArray(next.macros)) next.macros = [];
    if (!next.huds || typeof next.huds !== 'object') next.huds = {};
    if (!next.gameHudMap || typeof next.gameHudMap !== 'object') next.gameHudMap = {};
    if (!next.gameProfiles || typeof next.gameProfiles !== 'object') next.gameProfiles = {};
    next.currentGame = String(next.currentGame || '');
    if (!next.builder || typeof next.builder !== 'object') next.builder = { name:'', sequence:[], editing:null, mode:'combo' };
    if (!Array.isArray(next.builder.sequence)) next.builder.sequence = [];
    if (!['combo','sequence','repeatHold','toggleHold'].includes(next.builder.mode)) next.builder.mode = 'combo';
    next.floatingSticks = next.floatingSticks !== false;
    if (!next.bubble || typeof next.bubble !== 'object') next.bubble = { x:18, y:18 };
    next.bubble.x = clamp(Number(next.bubble.x) || 18, 6, innerWidth - 62);
    next.bubble.y = clamp(Number(next.bubble.y) || 18, 6, innerHeight - 62);
    next.activeHud = clamp(Number(next.activeHud) || 1, 1, 4);
    next.opacity = clamp(Number(next.opacity) || 72, 25, 100);
    next.analogSensL = clamp(Number(next.analogSensL) || 100, 50, 200);
    next.analogSensR = clamp(Number(next.analogSensR) || 100, 50, 200);
    next.analogDeadzoneL = clamp(Number(next.analogDeadzoneL) || 0, 0, 30);
    next.analogDeadzoneR = clamp(Number(next.analogDeadzoneR) || 0, 0, 30);
    next.ultraHD = Boolean(next.ultraHD);
    next.ultraLevel = clamp(Number(next.ultraLevel) || 55, 0, 100);
    if (!next.visualMode && next.superResMode) {
      if (next.superResMode === 'clean') next.visualMode = 'natural';
      else if (next.superResMode === 'strong') next.visualMode = 'vibrant';
      else next.visualMode = 'realistic';
    }
    if (!['natural','realistic','cinematic','vibrant'].includes(next.visualMode)) next.visualMode = 'realistic';
    return next;
  }

  function defaultLayout() {
    const layout = {};
    for (const b of BUTTONS) layout[b.id] = { x:b.x, y:b.y, size:b.size };
    return layout;
  }

  function currentGameKey() {
    const path = (location.pathname || '').replace(/\/+$/, '');
    const title = (document.title || '').trim().slice(0, 80);
    return `${location.hostname}${path}::${title}`;
  }

  function makeProfileFromCurrent() {
    return {
      activeHud: cfg.activeHud,
      huds: clone(cfg.huds || {}),
      layout: clone(cfg.layout || defaultLayout()),
      macros: clone(cfg.macros || []),
      opacity: cfg.opacity
    };
  }

  function applyGameProfile(profile) {
    cfg.activeHud = clamp(Number(profile?.activeHud) || 1, 1, 4);
    cfg.huds = clone(profile?.huds || {});
    cfg.layout = clone(profile?.layout || defaultLayout());
    cfg.macros = clone(profile?.macros || []);
    cfg.opacity = profile?.opacity ?? cfg.opacity ?? 72;

    const hud = cfg.huds[String(cfg.activeHud)];
    if (hud) {
      cfg.layout = clone(hud.layout || cfg.layout || defaultLayout());
      cfg.macros = clone(hud.macros || cfg.macros || []);
      cfg.opacity = hud.opacity ?? cfg.opacity;
    }
  }

  function saveCurrentGameProfile() {
    if (!cfg.currentGame) return;
    cfg.gameProfiles[cfg.currentGame] = makeProfileFromCurrent();
  }

  function loadGameProfileFor(key) {
    if (!key) return;

    if (cfg.currentGame && cfg.currentGame !== key) {
      saveCurrentGameProfile();
    }

    cfg.currentGame = key;

    if (!cfg.gameProfiles[key]) {
      cfg.gameProfiles[key] = {
        activeHud: 1,
        huds: {},
        layout: defaultLayout(),
        macros: [],
        opacity: cfg.opacity ?? 72
      };
    }

    applyGameProfile(cfg.gameProfiles[key]);
    releaseAll();
    showToast('HUD do jogo carregado');
  }

  function isInGame() {
    const href = (location.href || '').toLowerCase();
    const path = (location.pathname || '').toLowerCase();
    const title = (document.title || '').toLowerCase();

    const launch = /\/launch|\/play\/launch|remote-play|stream/.test(path);
    const gamepadTest = /gamepad|html5-gamepad-test/.test(href);
    const largeVideo = [...document.querySelectorAll('video')].some(v => {
      const r = v.getBoundingClientRect?.();
      return r && r.width > innerWidth * .45 && r.height > innerHeight * .35;
    });
    const largeCanvas = [...document.querySelectorAll('canvas')].some(c => {
      const r = c.getBoundingClientRect?.();
      return r && r.width > innerWidth * .45 && r.height > innerHeight * .35;
    });
    const menuPage = /library|store|search|settings|home|buscar|loja|configura/.test(title + ' ' + path);

    return Boolean(gamepadTest || launch || largeVideo || largeCanvas) && !menuPage;
  }

  function updateGameState() {
    const detected = isInGame();
    const key = detected ? currentGameKey() : '';

    if (detected && key && cfg.currentGame !== key) {
      loadGameProfileFor(key);
      cfg.gameDetected = true;
      render();
      saveConfig(true);
      return;
    }

    if (cfg.gameDetected !== detected) {
      cfg.gameDetected = detected;
      if (!detected) {
        saveCurrentGameProfile();
        releaseAll();
      }
      render();
      saveConfig();
    }
  }

  function controlsAllowed() {
    return cfg.enabled && cfg.visible && (!cfg.onlyInGame || cfg.gameDetected);
  }

  function saveCurrentHud() {
    cfg.huds[String(cfg.activeHud)] = {
      name: `HUD ${cfg.activeHud}`,
      layout: clone(cfg.layout),
      macros: clone(cfg.macros),
      opacity: cfg.opacity
    };
    cfg.gameHudMap[currentGameKey()] = cfg.activeHud;
    saveCurrentGameProfile();
    saveConfig(true);
    showToast(`HUD ${cfg.activeHud} salvo`);
  }

  function saveCurrentHudSilent() {
    cfg.huds[String(cfg.activeHud)] = {
      name: `HUD ${cfg.activeHud}`,
      layout: clone(cfg.layout),
      macros: clone(cfg.macros),
      opacity: cfg.opacity
    };
  }

  function loadHud(slot) {
    slot = clamp(Number(slot) || 1, 1, 4);
    saveCurrentHudSilent();
    cfg.activeHud = slot;
    const hud = cfg.huds[String(slot)];
    if (hud) {
      cfg.layout = clone(hud.layout || defaultLayout());
      cfg.macros = clone(hud.macros || []);
      cfg.opacity = hud.opacity ?? cfg.opacity;
    } else {
      cfg.layout = defaultLayout();
      cfg.macros = [];
    }
    cfg.selected = null;
    cfg.gameHudMap[currentGameKey()] = slot;
    saveCurrentGameProfile();
    releaseAll();
    render();
    saveConfig(true);
    showToast(`HUD ${slot}`);
  }

  function applyAutoHudForGame() {
    const key = currentGameKey();
    if (!key) return;
    if (cfg.currentGame !== key) loadGameProfileFor(key);
  }

  function createGamepad() {
    const buttons = Array.from({ length: 17 }, () => ({ pressed:false, touched:false, value:0 }));
    return {
      id: 'Xbox 360 Controller (Cloud Controller Lite V16)',
      index: 0,
      connected: true,
      mapping: 'standard',
      timestamp: performance.now(),
      axes: [0,0,0,0],
      buttons
    };
  }

  function updateTimestamp() { gamepad.timestamp = performance.now(); }

  function hasActiveInput() {
    return pressedPointers.size > 0
      || activeMacroPresses.size > 0
      || activeRepeatMacros.size > 0
      || Boolean(activeSticks.L || activeSticks.R);
  }

  function startActiveInputPulse() {
    if (activeInputFrame) return;

    const tick = () => {
      if (!hasActiveInput()) {
        activeInputFrame = 0;
        return;
      }

      updateTimestamp();
      activeInputFrame = requestAnimationFrame(tick);
    };

    activeInputFrame = requestAnimationFrame(tick);
  }

  function setButton(index, down) {
    const b = gamepad.buttons[index];
    if (!b) return;
    b.pressed = Boolean(down);
    b.touched = Boolean(down);
    b.value = down ? 1 : 0;
    updateTimestamp();
  }

  function setAxis(index, value) {
    gamepad.axes[index] = clamp(value, -1, 1);
    updateTimestamp();
  }

  function tuneAnalog(side, ax, ay) {
    const sens = (side === 'L' ? cfg.analogSensL : cfg.analogSensR) / 100;
    const dz = clamp((side === 'L' ? cfg.analogDeadzoneL : cfg.analogDeadzoneR) / 100, 0, .30);
    const mag = Math.hypot(ax, ay);

    if (!mag || mag < dz) return { ax:0, ay:0 };

    const live = 1 - dz;
    const scaledMag = live > 0 ? clamp(((mag - dz) / live) * sens, 0, 1) : clamp(mag * sens, 0, 1);
    const k = scaledMag / mag;

    return { ax:clamp(ax * k, -1, 1), ay:clamp(ay * k, -1, 1) };
  }

  function patchGamepad() {
    if (navigator.__ccLiteV16Patched) return;
    navigator.__ccLiteV16Patched = true;

    const nativeGetGamepads = navigator.getGamepads ? navigator.getGamepads.bind(navigator) : null;

    try {
      Object.defineProperty(navigator, 'getGamepads', {
        configurable: true,
        value: () => {
          const pads = nativeGetGamepads ? Array.from(nativeGetGamepads() || []) : [];
          while (pads.length < 4) pads.push(null);
          pads[0] = gamepad;
          return pads;
        }
      });
    } catch (_) {}

    setTimeout(() => {
      try { window.dispatchEvent(new GamepadEvent('gamepadconnected', { gamepad })); }
      catch (_) { window.dispatchEvent(new Event('gamepadconnected')); }
    }, 300);
  }

  function css() {
    return `
      #cc-lite-root, #cc-lite-root * { box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
      #cc-lite-root { position:fixed; inset:0; z-index:2147483647; pointer-events:none; font-family:system-ui,-apple-system,Segoe UI,sans-serif; color:white; }
      #cc-lite-layer { position:fixed; inset:0; pointer-events:auto; touch-action:none; }
      #cc-lite-root[data-controls="false"] #cc-lite-layer { display:none !important; }
      html.cc-ultra-hd video,
      html.cc-ultra-hd canvas {
        transform:translateZ(0) scale(1.0001) !important;
        backface-visibility:hidden !important;
        image-rendering:auto !important;
        will-change:filter,transform !important;
      }

      html.cc-ultra-hd.cc-visual-natural video {
        filter:
          contrast(calc(1 + (var(--cc-ultra-level,55) * .0012)))
          saturate(calc(1 + (var(--cc-ultra-level,55) * .0010)))
          brightness(calc(1 + (var(--cc-ultra-level,55) * .0005))) !important;
      }

      html.cc-ultra-hd.cc-visual-realistic video {
        filter:
          url(#cc-visual-sharp)
          contrast(calc(1 + (var(--cc-ultra-level,55) * .0020)))
          saturate(calc(1 + (var(--cc-ultra-level,55) * .0018)))
          brightness(calc(1 + (var(--cc-ultra-level,55) * .0006))) !important;
      }

      html.cc-ultra-hd.cc-visual-cinematic video {
        filter:
          url(#cc-visual-sharp)
          contrast(calc(1 + (var(--cc-ultra-level,55) * .0028)))
          saturate(calc(1 + (var(--cc-ultra-level,55) * .0008)))
          brightness(calc(1 - (var(--cc-ultra-level,55) * .00025)))
          sepia(calc(var(--cc-ultra-level,55) * .0012)) !important;
      }

      html.cc-ultra-hd.cc-visual-vibrant video {
        filter:
          url(#cc-visual-strong)
          contrast(calc(1 + (var(--cc-ultra-level,55) * .0024)))
          saturate(calc(1 + (var(--cc-ultra-level,55) * .0032)))
          brightness(calc(1 + (var(--cc-ultra-level,55) * .0009))) !important;
      }

      html.cc-ultra-hd.cc-visual-natural canvas {
        filter:
          contrast(calc(1 + (var(--cc-ultra-level,55) * .0010)))
          saturate(calc(1 + (var(--cc-ultra-level,55) * .0009))) !important;
      }

      html.cc-ultra-hd.cc-visual-realistic canvas {
        filter:
          url(#cc-visual-sharp)
          contrast(calc(1 + (var(--cc-ultra-level,55) * .0016)))
          saturate(calc(1 + (var(--cc-ultra-level,55) * .0015))) !important;
      }

      html.cc-ultra-hd.cc-visual-cinematic canvas {
        filter:
          url(#cc-visual-sharp)
          contrast(calc(1 + (var(--cc-ultra-level,55) * .0022)))
          saturate(calc(1 + (var(--cc-ultra-level,55) * .0006)))
          sepia(calc(var(--cc-ultra-level,55) * .0010)) !important;
      }

      html.cc-ultra-hd.cc-visual-vibrant canvas {
        filter:
          url(#cc-visual-strong)
          contrast(calc(1 + (var(--cc-ultra-level,55) * .0020)))
          saturate(calc(1 + (var(--cc-ultra-level,55) * .0028))) !important;
      }


      .cc-control, .cc-macro { position:fixed; transform:translate(-50%,-50%); pointer-events:auto; touch-action:none; user-select:none; border:2px solid rgba(240,240,240,.85); color:rgba(245,245,245,.94); background:rgba(0,0,0,.18); display:flex; align-items:center; justify-content:center; font:900 13px/1 system-ui; opacity:var(--cc-opacity,.72); }
      .cc-control::before, .cc-macro::before { content:''; position:absolute; inset:-16px; border-radius:inherit; pointer-events:auto; background:transparent; }
      .cc-control { border-radius:999px; }
      .cc-control[data-type="button"][data-wide="true"] { border-radius:16px; }
      .cc-control[data-pressed="true"], .cc-macro[data-pressed="true"] { outline:3px solid rgba(255,255,255,.55); }
      .cc-control[data-selected="true"], .cc-macro[data-selected="true"] { outline:3px dashed rgba(120,255,160,.95); }
      #cc-lite-root[data-edit="true"] .cc-control, #cc-lite-root[data-edit="true"] .cc-macro { box-shadow:0 0 0 2px rgba(255,255,255,.18) inset; }

      .cc-stick-knob { width:44%; height:44%; border-radius:999px; border:2px solid rgba(255,255,255,.78); pointer-events:none; display:flex; align-items:center; justify-content:center; font:900 12px/1 system-ui; }
      .cc-float-stick { position:fixed; transform:translate(-50%,-50%); pointer-events:none; border-radius:999px; border:2px solid rgba(240,240,240,.70); background:rgba(0,0,0,.10); display:flex; align-items:center; justify-content:center; opacity:var(--cc-opacity,.72); }
      .cc-float-knob { width:42%; height:42%; border-radius:999px; border:2px solid rgba(255,255,255,.82); display:flex; align-items:center; justify-content:center; font:900 12px/1 system-ui; color:rgba(255,255,255,.90); }
      .cc-macro { border-radius:18px; min-width:58px; min-height:40px; padding:0 8px; background:rgba(255,255,255,.08); }

      #cc-lite-bubble { position:fixed; z-index:2147483647; width:52px; height:52px; border-radius:999px; pointer-events:auto; touch-action:none; display:flex; align-items:center; justify-content:center; border:1px solid rgba(255,255,255,.18); background:rgba(5,7,11,.88); box-shadow:0 12px 30px rgba(0,0,0,.35); color:white; font:950 16px/1 system-ui; user-select:none; }
      #cc-lite-bubble[data-open="true"] { background:rgba(255,255,255,.92); color:#05070b; }

      .cc-ui { min-height:34px; border-radius:12px; border:1px solid rgba(255,255,255,.14); background:rgba(255,255,255,.08); color:white; font:850 11px/1 system-ui; padding:0 9px; pointer-events:auto; touch-action:manipulation; }
      .cc-ui[data-on="true"] { background:rgba(255,255,255,.92); color:#05070b; border-color:transparent; }

      #cc-lite-panel { position:fixed; left:50%; top:58px; transform:translateX(-50%); z-index:2147483647; width:min(420px,calc(100vw - 18px)); max-height:min(78vh,640px); overflow:auto; pointer-events:auto; display:none; gap:10px; padding:12px; border-radius:20px; background:rgba(5,7,11,.94); border:1px solid rgba(255,255,255,.16); box-shadow:0 18px 45px rgba(0,0,0,.42); }
      #cc-lite-panel[data-open="true"] { display:grid; }
      .cc-tabs, .cc-grid { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:8px; }
      .cc-tabs { grid-template-columns:repeat(2,minmax(0,1fr)); }
      .cc-card { display:grid; gap:8px; padding:10px; border-radius:16px; border:1px solid rgba(255,255,255,.10); background:rgba(255,255,255,.04); }
      .cc-row { display:grid; grid-template-columns:105px 1fr 48px; gap:8px; align-items:center; font:800 11px/1 system-ui; color:rgba(245,245,245,.82); }
      .cc-row input, .cc-row select { width:100%; }
      .cc-select, .cc-input { width:100%; min-height:34px; border-radius:12px; border:1px solid rgba(255,255,255,.14); background:rgba(0,0,0,.24); color:white; padding:0 10px; font:800 12px/1 system-ui; }
      .cc-note { font:750 11px/1.35 system-ui; color:rgba(235,235,235,.70); }
      .cc-section { display:none; gap:10px; }
      #cc-lite-panel[data-tab="hud"] [data-section="hud"],
      #cc-lite-panel[data-tab="macro"] [data-section="macro"] { display:grid; }
      .cc-list { display:grid; gap:7px; }
      .cc-list-item { display:grid; grid-template-columns:1fr auto auto auto; gap:6px; align-items:center; padding:7px; border-radius:14px; border:1px solid rgba(255,255,255,.10); background:rgba(255,255,255,.04); }
      .cc-list-item b { font:850 11px/1.2 system-ui; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      #cc-lite-toast { position:fixed; left:50%; bottom:18px; transform:translateX(-50%); z-index:2147483647; display:none; padding:10px 12px; border-radius:999px; background:rgba(5,7,11,.92); border:1px solid rgba(255,255,255,.14); color:white; font:850 12px/1 system-ui; pointer-events:none; }
      #cc-lite-toast[data-show="true"] { display:block; }
    `;
  }

  function createUI() {
    if (document.getElementById('cc-lite-root')) return;

    root = document.createElement('div');
    root.id = 'cc-lite-root';

    const style = document.createElement('style');
    style.textContent = css();

    layer = document.createElement('div');
    layer.id = 'cc-lite-layer';

    bubble = document.createElement('div');
    bubble.id = 'cc-lite-bubble';
    bubble.textContent = '☰';
    bubble.title = 'Abrir Config';

    panel = document.createElement('div');
    panel.id = 'cc-lite-panel';
    panel.innerHTML = `
      <div class="cc-tabs">
        <button class="cc-ui" data-tab="hud">HUD</button>
        <button class="cc-ui" data-tab="macro">Macro</button>
      </div>

      <div class="cc-section" data-section="hud">
        <div class="cc-card">
          <div class="cc-note">HUD: escolha, edite arrastando e salve para o jogo atual.</div>
          <div class="cc-grid">
            <button class="cc-ui" data-action="touch">Touch</button>
            <button class="cc-ui" data-action="edit">Edit</button>
            <button class="cc-ui" data-action="saveHud">Salvar HUD</button>
            <button class="cc-ui" data-hud="1">HUD 1</button>
            <button class="cc-ui" data-hud="2">HUD 2</button>
            <button class="cc-ui" data-hud="3">HUD 3</button>
            <button class="cc-ui" data-hud="4">HUD 4</button>
            <button class="cc-ui" data-action="resetHud">Reset HUD</button>
          </div>
          <div class="cc-row"><span>Opacidade</span><input type="range" min="25" max="100" data-setting="opacity"><b data-val="opacity"></b></div>
          <div class="cc-row"><span>Selecionado</span><input type="range" min="34" max="140" data-selected-size><b data-selected-name>Nada</b></div>
          <div class="cc-row"><span>Tam. LS</span><input type="range" min="60" max="160" data-analog-size="LS"><b data-analog-val="LS"></b></div>
          <div class="cc-row"><span>Tam. RS</span><input type="range" min="60" max="160" data-analog-size="RS"><b data-analog-val="RS"></b></div>
          <div class="cc-row"><span>Sens. LS</span><input type="range" min="50" max="200" data-setting="analogSensL"><b data-val="analogSensL"></b></div>
          <div class="cc-row"><span>Sens. RS</span><input type="range" min="50" max="200" data-setting="analogSensR"><b data-val="analogSensR"></b></div>
          <div class="cc-row"><span>Dead LS</span><input type="range" min="0" max="30" data-setting="analogDeadzoneL"><b data-val="analogDeadzoneL"></b></div>
          <div class="cc-row"><span>Dead RS</span><input type="range" min="0" max="30" data-setting="analogDeadzoneR"><b data-val="analogDeadzoneR"></b></div>
          <label class="cc-note"><input type="checkbox" data-toggle="ultraHD"> Melhorar imagem do jogo</label>
          <select class="cc-select" data-visual-mode>
            <option value="natural">Natural limpo</option>
            <option value="realistic">Realista</option>
            <option value="cinematic">Cinemático</option>
            <option value="vibrant">Bonito / Colorido</option>
          </select>
          <div class="cc-row"><span>Força visual</span><input type="range" min="0" max="100" data-setting="ultraLevel"><b data-val="ultraLevel"></b></div>
          <label class="cc-note"><input type="checkbox" data-toggle="onlyInGame"> Só mostrar dentro do jogo</label>
          <label class="cc-note"><input type="checkbox" data-toggle="floatingSticks"> Analógicos soltos</label>
          <div class="cc-note">Melhorar imagem do jogo é por fora: Natural, Realista, Cinemático ou Colorido. Ajuste Força visual.</div>
          <div class="cc-note">Liga Edit, toca num botão/macro para selecionar, arrasta para mover e usa “Selecionado” para aumentar/diminuir.</div>
        </div>
      </div>

      <div class="cc-section" data-section="macro">
        <div class="cc-card">
          <div class="cc-note">Macro: segurou no botão macro, ele fica pressionado até soltar. Repetir segurando e Clique segura continuam separados.</div>
          <input class="cc-input" data-macro-name placeholder="Nome do macro">
          <select class="cc-select" data-macro-mode>
            <option value="combo">Junto / Combo</option>
            <option value="sequence">Sequência</option>
            <option value="repeatHold">Repetir segurando</option>
            <option value="toggleHold">Clique segura</option>
          </select>
          <div class="cc-grid" data-picks></div>
          <div class="cc-note" data-sequence>Sequência: vazia</div>
          <div class="cc-grid">
            <button class="cc-ui" data-action="saveMacro">Adicionar/Atualizar</button>
            <button class="cc-ui" data-action="clearBuilder">Limpar</button>
            <button class="cc-ui" data-action="cancelEditMacro">Cancelar edição</button>
          </div>
        </div>
        <div class="cc-card">
          <div class="cc-note">Macros criados</div>
          <div class="cc-list" data-macro-list></div>
        </div>
      </div>
    `;

    toastEl = document.createElement('div');
    toastEl.id = 'cc-lite-toast';

    root.append(style, layer, bubble, panel, toastEl);
    (document.body || document.documentElement).appendChild(root);
    ensureVisualFilters();

    bindUI();
    render();
  }

  function blockNativeTouch(e) {
    if (e.target.closest?.('.cc-control, .cc-macro, #cc-lite-bubble')) {
      try { e.preventDefault(); } catch (_) {}
    }
  }

  function ensureVisualFilters() {
    if (document.getElementById('cc-visual-filters')) return;

    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.id = 'cc-visual-filters';
    svg.setAttribute('width', '0');
    svg.setAttribute('height', '0');
    svg.style.position = 'fixed';
    svg.style.left = '-9999px';
    svg.innerHTML = `
      <filter id="cc-visual-sharp">
        <feConvolveMatrix order="3" preserveAlpha="true" kernelMatrix="0 -0.45 0 -0.45 2.8 -0.45 0 -0.45 0"/>
      </filter>
      <filter id="cc-visual-strong">
        <feConvolveMatrix order="3" preserveAlpha="true" kernelMatrix="0 -0.75 0 -0.75 4.0 -0.75 0 -0.75 0"/>
      </filter>
    `;

    (document.body || document.documentElement).appendChild(svg);
  }

  function bindUI() {
    let bubbleDown = null;

    bubble.addEventListener('pointerdown', e => {
      e.preventDefault();
      e.stopPropagation();
      bubbleDown = { x:e.clientX, y:e.clientY, bx:cfg.bubble.x, by:cfg.bubble.y, moved:false };
      bubbleDrag = bubbleDown;
      try { bubble.setPointerCapture(e.pointerId); } catch (_) {}
    }, true);

    bubble.addEventListener('pointermove', e => {
      if (!bubbleDrag) return;
      const dx = e.clientX - bubbleDrag.x;
      const dy = e.clientY - bubbleDrag.y;
      if (Math.abs(dx) + Math.abs(dy) > 6) bubbleDrag.moved = true;
      cfg.bubble.x = clamp(bubbleDrag.bx + dx, 6, innerWidth - 58);
      cfg.bubble.y = clamp(bubbleDrag.by + dy, 6, innerHeight - 58);
      renderBubble();
    }, true);

    bubble.addEventListener('pointerup', e => {
      e.preventDefault();
      e.stopPropagation();
      const wasDrag = bubbleDrag?.moved;
      bubbleDrag = null;
      saveConfig();
      if (!wasDrag) {
        cfg.menuOpen = !cfg.menuOpen;
        render();
        saveConfig();
      }
    }, true);

    layer.addEventListener('pointerdown', handleLayerPointerDown, true);

    const activate = (e) => {
      const target = e.target.closest?.('[data-action], [data-tab], [data-hud], [data-pick], [data-macro-run], [data-macro-edit], [data-macro-del]');
      if (!target || !panel.contains(target)) return;

      const now = Date.now();
      if (now - lastActionAt < 120) return;
      lastActionAt = now;

      e.preventDefault();
      e.stopPropagation();

      runUI(target);
    };

    panel.addEventListener('touchend', activate, { capture:true, passive:false });
    panel.addEventListener('pointerup', activate, true);
    panel.addEventListener('click', activate, true);

    panel.addEventListener('input', e => {
      const range = e.target.closest('[data-setting]');
      if (range) {
        cfg[range.dataset.setting] = Number(range.value);
        render();
        saveConfig();
        return;
      }

      const analogSize = e.target.closest('[data-analog-size]');
      if (analogSize) {
        const id = analogSize.dataset.analogSize;
        const p = cfg.layout[id] || getPos(id);
        p.size = clamp(Number(analogSize.value) || 92, 60, 160);
        cfg.layout[id] = p;
        renderControls();
        renderAnalogSizeControls();
        saveConfig();
        return;
      }

      const selectedSize = e.target.closest('[data-selected-size]');
      if (selectedSize) {
        setSelectedSize(Number(selectedSize.value));
        renderControls();
        renderSelectedControls();
        saveConfig();
        return;
      }

      const name = e.target.closest('[data-macro-name]');
      if (name) {
        cfg.builder.name = name.value;
        saveConfig();
      }
    }, true);

    panel.addEventListener('change', e => {
      const toggle = e.target.closest('[data-toggle]');
      if (toggle) {
        cfg[toggle.dataset.toggle] = Boolean(toggle.checked);
        render();
        saveConfig(true);
        return;
      }

      const mode = e.target.closest('[data-macro-mode]');
      if (mode) {
        cfg.builder.mode = ['combo','sequence','repeatHold','toggleHold'].includes(mode.value) ? mode.value : 'combo';
        saveConfig();
        return;
      }

      const visualMode = e.target.closest('[data-visual-mode]');
      if (visualMode) {
        cfg.visualMode = ['natural','realistic','cinematic','vibrant'].includes(visualMode.value) ? visualMode.value : 'realistic';
        render();
        saveConfig(true);
      }
    }, true);

    window.addEventListener('pointermove', handlePointerMove, true);
    window.addEventListener('pointerup', handlePointerUp, true);
    window.addEventListener('pointercancel', handlePointerUp, true);
    window.addEventListener('touchstart', blockNativeTouch, { capture:true, passive:false });
    window.addEventListener('touchmove', blockNativeTouch, { capture:true, passive:false });
    window.addEventListener('resize', render);
  }

  function runUI(target) {
    const tab = target.dataset.tab;
    if (tab) {
      cfg.activeTab = tab;
      render();
      saveConfig();
      return;
    }

    const hud = target.dataset.hud;
    if (hud) {
      loadHud(Number(hud));
      return;
    }

    const pick = target.dataset.pick;
    if (pick) {
      cfg.builder.sequence.push(Number(pick));
      render();
      saveConfig();
      return;
    }

    const run = target.dataset.macroRun;
    if (run !== undefined) {
      runMacro(Number(run));
      return;
    }

    const edit = target.dataset.macroEdit;
    if (edit !== undefined) {
      editMacro(Number(edit));
      return;
    }

    const del = target.dataset.macroDel;
    if (del !== undefined) {
      deleteMacro(Number(del));
      return;
    }

    const action = target.dataset.action;
    if (action === 'touch') { cfg.visible = !cfg.visible; if (!cfg.visible) releaseAll(); }
    if (action === 'edit') { cfg.edit = !cfg.edit; releaseAll(); showToast(cfg.edit ? 'Edit ligado: arraste sem abrir config' : 'Edit desligado'); }
    if (action === 'saveHud') saveCurrentHud();
    if (action === 'resetHud') resetHud();
    if (action === 'saveMacro') saveMacroFromBuilder();
    if (action === 'clearBuilder') clearBuilder();
    if (action === 'cancelEditMacro') { cfg.builder.editing = null; cfg.builder.name = ''; cfg.builder.sequence = []; cfg.builder.mode = 'combo'; }

    render();
    saveConfig();
  }

  function render() {
    if (!root) return;

    root.dataset.controls = String(controlsAllowed());
    root.dataset.edit = String(cfg.edit);
    root.style.setProperty('--cc-opacity', String(clamp(cfg.opacity,25,100) / 100));
    document.documentElement.classList.toggle('cc-ultra-hd', Boolean(cfg.ultraHD));
    document.documentElement.classList.toggle('cc-visual-natural', cfg.ultraHD && cfg.visualMode === 'natural');
    document.documentElement.classList.toggle('cc-visual-realistic', cfg.ultraHD && cfg.visualMode === 'realistic');
    document.documentElement.classList.toggle('cc-visual-cinematic', cfg.ultraHD && cfg.visualMode === 'cinematic');
    document.documentElement.classList.toggle('cc-visual-vibrant', cfg.ultraHD && cfg.visualMode === 'vibrant');
    document.documentElement.style.setProperty('--cc-ultra-level', String(clamp(cfg.ultraLevel,0,100)));
    panel.dataset.open = String(cfg.menuOpen);
    panel.dataset.tab = cfg.activeTab || 'hud';

    renderBubble();

    for (const btn of root.querySelectorAll('[data-action]')) {
      const a = btn.dataset.action;
      let on = false;
      if (a === 'touch') on = cfg.visible;
      if (a === 'edit') on = cfg.edit;
      btn.dataset.on = String(on);
    }
    for (const b of root.querySelectorAll('[data-tab]')) b.dataset.on = String(b.dataset.tab === cfg.activeTab);
    for (const b of root.querySelectorAll('[data-hud]')) b.dataset.on = String(Number(b.dataset.hud) === cfg.activeHud);

    for (const key of ['opacity','analogSensL','analogSensR','analogDeadzoneL','analogDeadzoneR','ultraLevel']) {
      const input = panel.querySelector(`[data-setting="${key}"]`);
      const out = panel.querySelector(`[data-val="${key}"]`);
      if (input) input.value = String(cfg[key]);
      if (out) {
        if (key === 'opacity' || key.startsWith('analogSens')) out.textContent = `${cfg[key]}%`;
        else out.textContent = `${cfg[key]}%`;
      }
    }

    const only = panel.querySelector('[data-toggle="onlyInGame"]');
    if (only) only.checked = Boolean(cfg.onlyInGame);
    const floating = panel.querySelector('[data-toggle="floatingSticks"]');
    if (floating) floating.checked = Boolean(cfg.floatingSticks);
    const ultra = panel.querySelector('[data-toggle="ultraHD"]');
    if (ultra) ultra.checked = Boolean(cfg.ultraHD);
    const visualMode = panel.querySelector('[data-visual-mode]');
    if (visualMode) visualMode.value = cfg.visualMode || 'realistic';

    const macroName = panel.querySelector('[data-macro-name]');
    if (macroName && document.activeElement !== macroName) macroName.value = cfg.builder.name || '';

    const macroMode = panel.querySelector('[data-macro-mode]');
    if (macroMode) macroMode.value = cfg.builder.mode || 'combo';

    renderControls();
    renderMacroBuilder();
    renderMacroList();
    renderSelectedControls();
    renderAnalogSizeControls();
  }

  function renderBubble() {
    if (!bubble) return;
    bubble.dataset.open = String(cfg.menuOpen);
    bubble.style.left = `${clamp(cfg.bubble.x, 6, innerWidth - 58)}px`;
    bubble.style.top = `${clamp(cfg.bubble.y, 6, innerHeight - 58)}px`;
  }

  function getPos(id) {
    return cfg.layout[id] || defaultLayout()[id];
  }

  function isSelectedControl(id) {
    return cfg.selected && cfg.selected.kind === 'control' && cfg.selected.id === id;
  }

  function isSelectedMacro(index) {
    return cfg.selected && cfg.selected.kind === 'macro' && Number(cfg.selected.index) === Number(index);
  }

  function renderControls() {
    layer.innerHTML = '';

    for (const c of BUTTONS) {
      if (cfg.floatingSticks && c.type === 'stick') continue;
      const p = getPos(c.id);
      const el = document.createElement('div');
      el.className = 'cc-control';
      el.dataset.id = c.id;
      el.dataset.type = c.type;
      el.dataset.pressed = 'false';
      el.dataset.selected = String(isSelectedControl(c.id));
      if (['LB','RB','LT','RT','VIEW','MENU','L3','R3','UP','DOWN','LEFT','RIGHT'].includes(c.id)) el.dataset.wide = 'true';
      el.textContent = c.type === 'stick' ? '' : c.label;
      el.style.left = `${p.x * innerWidth}px`;
      el.style.top = `${p.y * innerHeight}px`;
      el.style.width = `${p.size}px`;
      el.style.height = `${p.size}px`;

      if (c.type === 'stick') {
        const knob = document.createElement('div');
        knob.className = 'cc-stick-knob';
        knob.textContent = c.label;
        el.appendChild(knob);
      }

      el.addEventListener('pointerdown', e => controlDown(e, c), true);
      layer.appendChild(el);
    }

    renderFloatingSticks();

    cfg.macros.forEach((m, i) => {
      const el = document.createElement('div');
      const size = clamp(Number(m.size) || 58, 34, 140);
      el.className = 'cc-macro';
      el.dataset.macroIndex = String(i);
      el.dataset.pressed = String(Boolean(m.held));
      el.dataset.selected = String(isSelectedMacro(i));
      el.textContent = m.name || `M${i+1}`;
      el.style.left = `${(m.x ?? .50) * innerWidth}px`;
      el.style.top = `${(m.y ?? .82) * innerHeight}px`;
      el.style.minWidth = `${size}px`;
      el.style.height = `${Math.max(38, Math.round(size * .70))}px`;
      el.addEventListener('pointerdown', e => macroDown(e, i), true);
      layer.appendChild(el);
    });
  }

  function renderSelectedControls() {
    const input = panel.querySelector('[data-selected-size]');
    const name = panel.querySelector('[data-selected-name]');
    if (!input || !name) return;

    const selected = getSelectedData();
    if (!selected) {
      input.value = '60';
      name.textContent = 'Nada';
      return;
    }

    input.value = String(selected.size);
    name.textContent = selected.label;
  }

  function renderAnalogSizeControls() {
    for (const id of ['LS','RS']) {
      const input = panel.querySelector(`[data-analog-size="${id}"]`);
      const out = panel.querySelector(`[data-analog-val="${id}"]`);
      const size = clamp(Number(getPos(id).size) || 92, 60, 160);
      if (input) input.value = String(size);
      if (out) out.textContent = `${size}px`;
    }
  }


  function getSelectedData() {
    if (!cfg.selected) return null;

    if (cfg.selected.kind === 'control') {
      const def = BUTTONS.find(b => b.id === cfg.selected.id);
      const p = cfg.layout[cfg.selected.id] || getPos(cfg.selected.id);
      return { label: cfg.selected.id, size: clamp(Number(p.size) || def?.size || 56, 34, 140) };
    }

    if (cfg.selected.kind === 'macro') {
      const m = cfg.macros[cfg.selected.index];
      if (!m) return null;
      return { label: m.name || `Macro ${Number(cfg.selected.index)+1}`, size: clamp(Number(m.size) || 58, 34, 140) };
    }

    return null;
  }

  function setSelectedSize(size) {
    size = clamp(Number(size) || 60, 34, 140);
    if (!cfg.selected) return;

    if (cfg.selected.kind === 'control') {
      const id = cfg.selected.id;
      const p = cfg.layout[id] || getPos(id);
      p.size = size;
      cfg.layout[id] = p;
    }

    if (cfg.selected.kind === 'macro') {
      const m = cfg.macros[cfg.selected.index];
      if (m) m.size = size;
    }
  }

  function renderMacroBuilder() {
    const picks = panel.querySelector('[data-picks]');
    if (picks) {
      picks.innerHTML = '';
      for (const cmd of COMMANDS) {
        const b = document.createElement('button');
        b.className = 'cc-ui';
        b.dataset.pick = String(cmd.button);
        b.textContent = cmd.id;
        picks.appendChild(b);
      }
    }
    const seq = panel.querySelector('[data-sequence]');
    if (seq) {
      const text = cfg.builder.sequence.map(buttonName).join(' + ') || 'vazia';
      const mode = macroModeLabel(cfg.builder.mode);
      seq.textContent = `${mode}: ${text}`;
    }
  }

  function renderMacroList() {
    const list = panel.querySelector('[data-macro-list]');
    if (!list) return;
    list.innerHTML = '';

    if (!cfg.macros.length) {
      const empty = document.createElement('div');
      empty.className = 'cc-note';
      empty.textContent = 'Nenhum macro criado.';
      list.appendChild(empty);
      return;
    }

    renderFloatingSticks();

    cfg.macros.forEach((m, i) => {
      const item = document.createElement('div');
      item.className = 'cc-list-item';
      const mode = macroModeLabel(m.mode);
      item.innerHTML = `
        <b>${escapeHtml(m.name || `Macro ${i+1}`)} • ${mode} • ${m.sequence.map(buttonName).join(' + ')}</b>
        <button class="cc-ui" data-macro-run="${i}">Testar</button>
        <button class="cc-ui" data-macro-edit="${i}">Editar</button>
        <button class="cc-ui" data-macro-del="${i}">Apagar</button>
      `;
      list.appendChild(item);
    });
  }

  function macroModeLabel(mode) {
    if (mode === 'sequence') return 'Sequência';
    if (mode === 'repeatHold') return 'Repetir';
    if (mode === 'toggleHold') return 'Clique segura';
    return 'Junto';
  }

  function buttonName(index) {
    return COMMANDS.find(c => c.button === Number(index))?.id || String(index);
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s]));
  }


  function handleLayerPointerDown(e) {
    if (!controlsAllowed() || !cfg.floatingSticks || cfg.edit) return;
    if (e.target.closest?.('.cc-control, .cc-macro, #cc-lite-bubble, #cc-lite-panel')) return;

    e.preventDefault();
    e.stopPropagation();

    const side = e.clientX < innerWidth / 2 ? 'L' : 'R';
    startFloatingStick(e, side);
  }

  function startFloatingStick(e, side) {
    const radius = clamp(Number(getPos(side === 'L' ? 'LS' : 'RS').size) || 92, 62, 140) / 2;
    activeSticks[side] = {
      pointerId: e.pointerId,
      center: { x:e.clientX, y:e.clientY },
      radius,
      floating: true,
      downAt: performance.now()
    };
    updateStick(side, e.clientX, e.clientY);
    renderControls();
    const floatingEl = layer.querySelector(`[data-float-side="${side}"]`);
    if (floatingEl) activeSticks[side].el = floatingEl;
    startActiveInputPulse();
    try { layer.setPointerCapture(e.pointerId); } catch (_) {}
  }

  function renderFloatingSticks() {
    if (!cfg.floatingSticks) return;

    for (const side of ['L','R']) {
      const s = activeSticks[side];
      if (!s || !s.floating) continue;

      const wrap = document.createElement('div');
      wrap.className = 'cc-float-stick';
      wrap.dataset.floatSide = side;
      wrap.style.left = `${s.center.x}px`;
      wrap.style.top = `${s.center.y}px`;
      wrap.style.width = `${s.radius * 2}px`;
      wrap.style.height = `${s.radius * 2}px`;

      const knob = document.createElement('div');
      knob.className = 'cc-float-knob';
      knob.textContent = side === 'L' ? 'LS' : 'RS';
      knob.style.transform = `translate(${s.dx || 0}px, ${s.dy || 0}px)`;

      wrap.appendChild(knob);
      layer.appendChild(wrap);
    }
  }

  function controlDown(e, c) {
    if (!controlsAllowed()) return;
    e.preventDefault();
    e.stopPropagation();

    if (cfg.edit) {
      cfg.selected = { kind:'control', id:c.id };
      cfg.activeTab = 'hud';
      startDrag(e, { kind:'control', id:c.id });
      renderControls();
      renderSelectedControls();
      saveConfig();
      return;
    }

    if (c.type === 'stick') {
      startStick(e, c);
      return;
    }

    updateTimestamp();
    setButton(c.button, true);
    startActiveInputPulse();
    pressedPointers.set(e.pointerId, {
      kind:'button',
      button:c.button,
      el:e.currentTarget,
      downAt:performance.now()
    });
    e.currentTarget.dataset.pressed = 'true';
    try { e.currentTarget.setPointerCapture(e.pointerId); } catch (_) {}
  }

  function macroDown(e, index) {
    if (!controlsAllowed()) return;
    e.preventDefault();
    e.stopPropagation();
    updateTimestamp();

    if (cfg.edit) {
      cfg.selected = { kind:'macro', index };
      cfg.activeTab = 'hud';
      startDrag(e, { kind:'macro', index });
      renderControls();
      renderSelectedControls();
      saveConfig();
      return;
    }

    const macro = cfg.macros[index];
    if (!macro) return;

    if (macro.mode === 'repeatHold') {
      startRepeatMacro(index, e.pointerId, e.currentTarget);
      try { e.currentTarget.setPointerCapture(e.pointerId); } catch (_) {}
      return;
    }

    if (macro.mode === 'toggleHold') {
      toggleHoldMacro(index);
      return;
    }

    // Pressionar macro: segurou fica pressionado, soltou ele solta.
    // Isso vale para Junto/Combo e também para macro antigo sem modo salvo.
    startMacroPress(index, e.pointerId, e.currentTarget);
    try { e.currentTarget.setPointerCapture(e.pointerId); } catch (_) {}
  }

  function startDrag(e, item) {
    const startX = e.clientX;
    const startY = e.clientY;
    let base;
    if (item.kind === 'control') {
      base = getPos(item.id);
    } else {
      const m = cfg.macros[item.index];
      base = { x:m.x ?? .5, y:m.y ?? .82 };
    }

    dragging.set(e.pointerId, { item, startX, startY, base:clone(base) });
    try { e.currentTarget.setPointerCapture(e.pointerId); } catch (_) {}
  }

  function startStick(e, c) {
    const rect = e.currentTarget.getBoundingClientRect();
    const center = { x:rect.left + rect.width / 2, y:rect.top + rect.height / 2 };
    activeSticks[c.stick] = {
      pointerId:e.pointerId,
      center,
      radius:rect.width / 2,
      el:e.currentTarget,
      downAt:performance.now()
    };
    updateStick(c.stick, e.clientX, e.clientY);
    startActiveInputPulse();
    try { e.currentTarget.setPointerCapture(e.pointerId); } catch (_) {}
  }

  function handlePointerMove(e) {
    const drag = dragging.get(e.pointerId);
    if (drag) {
      const dx = (e.clientX - drag.startX) / innerWidth;
      const dy = (e.clientY - drag.startY) / innerHeight;

      if (drag.item.kind === 'control') {
        const p = cfg.layout[drag.item.id] || getPos(drag.item.id);
        p.x = clamp(drag.base.x + dx, .04, .96);
        p.y = clamp(drag.base.y + dy, .06, .94);
        cfg.layout[drag.item.id] = p;
      } else {
        const m = cfg.macros[drag.item.index];
        if (m) {
          m.x = clamp(drag.base.x + dx, .05, .95);
          m.y = clamp(drag.base.y + dy, .08, .92);
        }
      }

      renderControls();
      return;
    }

    for (const side of ['L','R']) {
      const s = activeSticks[side];
      if (s && s.pointerId === e.pointerId) {
        updateStick(side, e.clientX, e.clientY);
        return;
      }
    }
  }

  function releasePressedPointer(pressed) {
    const elapsed = performance.now() - (pressed.downAt || 0);
    const waitMs = Math.max(0, QUICK_TAP_SAFETY_MS - elapsed);

    const finish = () => {
      setButton(pressed.button, false);
      if (pressed.el) pressed.el.dataset.pressed = 'false';
    };

    if (waitMs > 0) setTimeout(finish, waitMs);
    else finish();
  }

  function releaseStickWithBuffer(side, s) {
    const elapsed = performance.now() - (s.downAt || 0);
    const waitMs = Math.max(0, QUICK_TAP_SAFETY_MS - elapsed);

    const finish = () => {
      if (activeSticks[side] === s) activeSticks[side] = null;
      if (side === 'L') { setAxis(0,0); setAxis(1,0); }
      if (side === 'R') { setAxis(2,0); setAxis(3,0); }

      if (s.el) {
        const knob = s.el.querySelector('.cc-stick-knob, .cc-float-knob');
        if (knob) knob.style.transform = 'translate(0px, 0px)';
      }
      if (s.floating) renderControls();
    };

    if (waitMs > 0) setTimeout(finish, waitMs);
    else finish();
  }

  function handlePointerUp(e) {
    if (activeMacroPresses.has(e.pointerId)) {
      stopMacroPress(e.pointerId);
    }

    const repeating = activeRepeatMacros.get(e.pointerId);
    if (repeating) {
      repeating.stop = true;
      activeRepeatMacros.delete(e.pointerId);
      releaseMacroButtons(repeating.sequence);
      if (repeating.el) repeating.el.dataset.pressed = 'false';
    }

    const drag = dragging.get(e.pointerId);
    if (drag) {
      dragging.delete(e.pointerId);
      saveConfig(true);
      renderControls();
      return;
    }

    const pressed = pressedPointers.get(e.pointerId);
    if (pressed) {
      pressedPointers.delete(e.pointerId);
      releasePressedPointer(pressed);
    }

    for (const side of ['L','R']) {
      const s = activeSticks[side];
      if (s && s.pointerId === e.pointerId) {
        releaseStickWithBuffer(side, s);
      }
    }
  }

  function updateStick(side, x, y) {
    const s = activeSticks[side];
    if (!s) return;

    let dx = x - s.center.x;
    let dy = y - s.center.y;
    const dist = Math.hypot(dx, dy);
    const max = s.radius;
    if (dist > max) {
      dx = dx / dist * max;
      dy = dy / dist * max;
    }

    s.dx = dx;
    s.dy = dy;

    const rawAx = dx / max;
    const rawAy = dy / max;
    const tuned = tuneAnalog(side, rawAx, rawAy);
    const ax = tuned.ax;
    const ay = tuned.ay;

    updateTimestamp();
    if (side === 'L') { setAxis(0, ax); setAxis(1, ay); }
    if (side === 'R') { setAxis(2, ax); setAxis(3, ay); }

    if (s.el) {
      const knob = s.el.querySelector('.cc-stick-knob, .cc-float-knob');
      if (knob) knob.style.transform = `translate(${dx}px, ${dy}px)`;
    }
  }

  function releaseAll() {
    for (const repeat of activeRepeatMacros.values()) repeat.stop = true;
    activeRepeatMacros.clear();

    for (const pointerId of [...activeMacroPresses.keys()]) stopMacroPress(pointerId, true);
    activeMacroPresses.clear();
    for (const macro of cfg.macros || []) macro.held = false;
    for (let i = 0; i < gamepad.buttons.length; i++) setButton(i, false);
    for (let i = 0; i < gamepad.axes.length; i++) setAxis(i, 0);
    pressedPointers.clear();
    dragging.clear();
    activeSticks.L = null;
    activeSticks.R = null;
    if (activeInputFrame) {
      cancelAnimationFrame(activeInputFrame);
      activeInputFrame = 0;
    }
    for (const el of root?.querySelectorAll?.('[data-pressed]') || []) el.dataset.pressed = 'false';
  }


  function uniqueSequence(sequence) {
    return [...new Set((sequence || []).map(Number).filter(n => Number.isFinite(n)))];
  }

  function pressMacroButtons(sequence) {
    for (const btn of uniqueSequence(sequence)) setButton(btn, true);
  }

  function releaseMacroButtons(sequence) {
    for (const btn of uniqueSequence(sequence)) setButton(btn, false);
  }

  function startMacroPress(index, pointerId, el) {
    const macro = cfg.macros[index];
    if (!macro) return;

    const seq = uniqueSequence(macro.sequence);
    if (!seq.length) return;

    // Se o mesmo macro já estiver preso em outro toque, solta antes.
    for (const [pid, press] of [...activeMacroPresses.entries()]) {
      if (press.index === index) stopMacroPress(pid, true);
    }

    activeMacroPresses.set(pointerId, {
      index,
      sequence: seq,
      el,
      downAt: performance.now()
    });

    macro.held = true;
    pressMacroButtons(seq);
    startActiveInputPulse();
    if (el) el.dataset.pressed = 'true';
  }

  function stopMacroPress(pointerId, immediate = false) {
    const press = activeMacroPresses.get(pointerId);
    if (!press) return;

    activeMacroPresses.delete(pointerId);

    const finish = () => {
      releaseMacroButtons(press.sequence);
      const macro = cfg.macros[press.index];
      if (macro) macro.held = false;

      if (press.el) press.el.dataset.pressed = 'false';
      const currentEl = layer?.querySelector?.(`[data-macro-index="${press.index}"]`);
      if (currentEl) currentEl.dataset.pressed = 'false';
    };

    if (immediate) {
      finish();
      return;
    }

    const elapsed = performance.now() - (press.downAt || 0);
    const waitMs = Math.max(0, QUICK_TAP_SAFETY_MS - elapsed);
    if (waitMs > 0) setTimeout(finish, waitMs);
    else finish();
  }

  async function startRepeatMacro(index, pointerId, el) {
    const macro = cfg.macros[index];
    if (!macro || macro.running) return;

    const seq = uniqueSequence(macro.sequence);
    if (!seq.length) return;

    const state = { index, sequence:seq, stop:false, el };
    activeRepeatMacros.set(pointerId, state);
    macro.running = true;
    startActiveInputPulse();
    if (el) el.dataset.pressed = 'true';

    while (!state.stop && activeRepeatMacros.get(pointerId) === state) {
      if (macro.mode === 'sequence') {
        for (const btn of seq) {
          if (state.stop) break;
          setButton(btn, true);
          await wait(95);
          setButton(btn, false);
          await wait(55);
        }
      } else {
        pressMacroButtons(seq);
        await wait(115);
        releaseMacroButtons(seq);
        await wait(65);
      }
    }

    releaseMacroButtons(seq);
    macro.running = false;
    if (el) el.dataset.pressed = 'false';
  }

  function toggleHoldMacro(index) {
    const macro = cfg.macros[index];
    if (!macro) return;
    const seq = uniqueSequence(macro.sequence);
    if (!seq.length) return;

    const el = layer.querySelector(`[data-macro-index="${index}"]`);

    if (macro.held) {
      releaseMacroButtons(seq);
      macro.held = false;
      if (el) el.dataset.pressed = 'false';
      showToast('Macro soltou');
      return;
    }

    pressMacroButtons(seq);
    macro.held = true;
    if (el) el.dataset.pressed = 'true';
    showToast('Macro segurando');
  }

  async function runMacro(index) {
    const macro = cfg.macros[index];
    if (!macro || macro.running || !Array.isArray(macro.sequence) || !macro.sequence.length) return;

    const seq = uniqueSequence(macro.sequence);
    if (!seq.length) return;

    macro.running = true;
    const el = layer.querySelector(`[data-macro-index="${index}"]`);
    if (el) el.dataset.pressed = 'true';

    if (macro.mode === 'sequence') {
      for (const btn of seq) {
        setButton(btn, true);
        await wait(150);
        setButton(btn, false);
        await wait(80);
      }
    } else {
      pressMacroButtons(seq);
      await wait(190);
      releaseMacroButtons(seq);
    }

    macro.running = false;
    if (el && !macro.held) el.dataset.pressed = 'false';
  }

  function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function saveMacroFromBuilder() {
    const name = (cfg.builder.name || '').trim() || `Macro ${cfg.macros.length + 1}`;
    const seq = cfg.builder.sequence.map(Number).filter(n => Number.isFinite(n));
    const mode = ['combo','sequence','repeatHold','toggleHold'].includes(cfg.builder.mode) ? cfg.builder.mode : 'combo';

    if (!seq.length) {
      showToast('Escolha a sequência');
      return;
    }

    const editing = cfg.builder.editing;
    const data = {
      name: name.slice(0, 16),
      sequence: seq,
      mode,
      size: 58,
      x: .50 + Math.min(cfg.macros.length, 4) * .07,
      y: .82
    };

    if (editing !== null && editing !== undefined && cfg.macros[editing]) {
      data.x = cfg.macros[editing].x ?? data.x;
      data.y = cfg.macros[editing].y ?? data.y;
      data.size = cfg.macros[editing].size ?? data.size;
      cfg.macros[editing] = data;
      cfg.selected = { kind:'macro', index:editing };
      showToast('Macro atualizado');
    } else {
      cfg.macros.push(data);
      cfg.selected = { kind:'macro', index:cfg.macros.length - 1 };
      showToast('Macro adicionado');
    }

    clearBuilder();
    render();
    saveConfig(true);
  }

  function editMacro(index) {
    const m = cfg.macros[index];
    if (!m) return;
    cfg.builder = {
      name: m.name || '',
      sequence: clone(m.sequence || []),
      editing: index,
      mode: ['combo','sequence','repeatHold','toggleHold'].includes(m.mode) ? m.mode : 'combo'
    };
    cfg.selected = { kind:'macro', index };
    cfg.activeTab = 'macro';
    cfg.menuOpen = true;
    render();
    saveConfig();
  }

  function deleteMacro(index) {
    if (!cfg.macros[index]) return;

    for (const [pid, press] of [...activeMacroPresses.entries()]) {
      if (press.index === index) stopMacroPress(pid, true);
    }

    releaseMacroButtons(cfg.macros[index].sequence);
    cfg.macros[index].held = false;
    cfg.macros.splice(index, 1);
    if (cfg.builder.editing === index) clearBuilder();
    if (cfg.selected?.kind === 'macro' && Number(cfg.selected.index) === Number(index)) cfg.selected = null;
    render();
    saveConfig(true);
    showToast('Macro apagado');
  }

  function clearBuilder() {
    cfg.builder = { name:'', sequence:[], editing:null, mode:'combo' };
  }

  function resetHud() {
    cfg.layout = defaultLayout();
    cfg.macros = [];
    cfg.selected = null;
    clearBuilder();
    releaseAll();
    render();
    saveCurrentGameProfile();
    saveConfig(true);
    showToast('HUD resetado');
  }

  function showToast(text) {
    if (!toastEl) return;
    toastEl.textContent = text;
    toastEl.dataset.show = 'true';
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => { toastEl.dataset.show = 'false'; }, 1400);
  }

  function init() {
    patchGamepad();
    createUI();
    applyAutoHudForGame();
    updateGameState();
    setInterval(updateGameState, 2000);
    setInterval(updateTimestamp, 1000);
  }

  if (document.body) init();
  else window.addEventListener('load', init, { once:true });
})();
