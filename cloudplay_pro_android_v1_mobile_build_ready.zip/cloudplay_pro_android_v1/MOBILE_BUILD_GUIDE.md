# Como gerar o APK pelo celular

Esse projeto está preparado para gerar APK usando GitHub Actions, sem Android Studio.

## Passo a passo pelo celular

1. Crie uma conta no GitHub ou entre na sua conta.
2. Crie um repositório novo.
3. Envie todos os arquivos desse ZIP para o repositório.
4. Abra a aba **Actions**.
5. Toque em **Build APK**.
6. Toque em **Run workflow**.
7. Espere terminar.
8. Entre na execução finalizada e baixe o artifact:
   **CloudPlay-Pro-debug-apk**
9. Dentro dele vai estar:
   **app-debug.apk**

## Observação

Esse APK é debug, então o Android pode avisar que é app desconhecido.
Ative instalação de fontes desconhecidas para instalar.

## O app

- Abre o xCloud em tela cheia
- Injeta o HUD/touch
- Já vem com o controle V16
