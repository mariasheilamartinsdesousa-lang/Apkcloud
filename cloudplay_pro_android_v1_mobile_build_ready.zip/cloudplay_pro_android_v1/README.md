# CloudPlay Pro Android v1

App Android criado do zero para abrir o xCloud em WebView e injetar o HUD/touch.

## O que tem

- Abre `https://www.xbox.com/play`
- Tela cheia
- Modo paisagem
- Cookies/login ativados
- JavaScript e DOM Storage ativados
- Mantém tela ligada
- Injeta o HUD do Cloud Controller V16
- Mantém:
  - controle touch
  - macro
  - HUD por jogo
  - resposta 0ms
  - sensibilidade/deadzone
  - melhorar imagem do jogo

## Como compilar

1. Abra a pasta no Android Studio.
2. Espere sincronizar o Gradle.
3. Clique em **Build > Build APK(s)**.
4. Instale o APK gerado no Android.

## Arquivo principal do HUD

`app/src/main/assets/cloud_controller.js`

Se quiser trocar o HUD depois, substitua esse arquivo pelo `page.js` de outra versão.

## Importante

Esse app não cria nuvem própria.
Ele só abre o site oficial do Xbox Cloud Gaming dentro de um app WebView e injeta o nosso HUD.

Você ainda precisa da sua conta Xbox/Microsoft e Game Pass quando o jogo exigir.


## Gerar APK pelo celular

Também incluí `.github/workflows/build-apk.yml`.

Você pode subir esse projeto no GitHub pelo celular e gerar o APK na aba Actions.

Leia:
`MOBILE_BUILD_GUIDE.md`
